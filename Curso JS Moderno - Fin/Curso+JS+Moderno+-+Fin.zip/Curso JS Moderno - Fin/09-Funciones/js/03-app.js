// Funciones del Lenguaje

// JavaScript cuenta con más de 4 mil funciones 

// Java, python, PHP todos incluyen miles de funciones, estas funciones se les conoce como la libreria estandard..

// En JavaScript no hay librería estandard, pero si hay funciones que son parte digamos del Core...

alert('Hubo un error...');

prompt('Cual es tu edad?');


parseInt('1');

// Son ejemplos de funciones. puedes ver que cuentan con un nombre y son llamadas con un parentesis...