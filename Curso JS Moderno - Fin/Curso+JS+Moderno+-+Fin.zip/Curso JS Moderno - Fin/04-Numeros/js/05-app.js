// Veamos como ir incrementando un valor de 1 en 1 o en determinada cantidad

// Incluir incremento por 1 y menos 1

let puntaje = 5;
puntaje++;
puntaje--;
++puntaje;
--puntaje;

puntaje += 3;
puntaje -= 3;

console.log(puntaje);