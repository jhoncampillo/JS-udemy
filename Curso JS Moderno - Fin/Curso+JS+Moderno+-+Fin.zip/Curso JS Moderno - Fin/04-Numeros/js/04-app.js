// El Orden en que se ejecutan las operaciones en JavaScript es igual que en la escuela


let resultado 
// El orden de las operaciones

resultado = 20 + 30 * 2;
resultado =  ( 20 + 30 ) * 2;

// 20% De descuento en un carrito de compra.
resultado = ( 20+10+30+40+50 ) * .20;

console.log(resultado);