import App from './classes/App.js';

const app = new App();